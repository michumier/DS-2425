package adapters;

public class RestaurantAdapter {

}
