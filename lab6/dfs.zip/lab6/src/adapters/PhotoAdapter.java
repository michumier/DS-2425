
package adapters;

public class PhotoAdapter {

}
