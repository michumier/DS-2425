package adapters;

public class MonumentAdapter implements Adapter {

    @Override
    public Coordinates getCoordinates() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getCoordinates'");
    }

    @Override
    public String shortClick() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'shortClick'");
    }

    @Override
    public void longClick() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'longClick'");
    }
    

}
